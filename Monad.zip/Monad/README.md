# Monad
High-performance L1 blockchain with parallel EVM execution.